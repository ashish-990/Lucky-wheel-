let walletAmount = parseInt(localStorage.getItem('wallet')) || 0;
document.getElementById('walletAmount').innerText = walletAmount;

const adsLinks = [
"https://dreadfulrulingextension.com/xfkzs3b85?key=9df7f84ede014babbcc6e14c81a4ce6b",
"https://dreadfulrulingextension.com/wv7n729zu?key=dfc9a55b32b16c9c2a12087ddd3ceaa6",
"https://dreadfulrulingextension.com/ct8rjb02pj?key=1c3aea89b58347b73d58ac51a2e5e36b"
];
let currentAdIndex = 0;

document.getElementById('spinButton').addEventListener('click', () => {
    let reward = getRandomReward();
    if (reward !== 'Try Again') {
        walletAmount += reward;
        localStorage.setItem('wallet', walletAmount);
        document.getElementById('walletAmount').innerText = walletAmount;
    }
    window.open(adsLinks[currentAdIndex], '_blank');
    currentAdIndex = (currentAdIndex + 1) % adsLinks.length;
});

function getRandomReward() {
    let rewards = [2, 4, 5, 8, 'Try Again'];
    return rewards[Math.floor(Math.random() * rewards.length)];
}

document.getElementById('withdrawForm').addEventListener('submit', (e) => {
    e.preventDefault();
    alert("Withdraw request sent to: ashishanand5438990@gmail.com");
});